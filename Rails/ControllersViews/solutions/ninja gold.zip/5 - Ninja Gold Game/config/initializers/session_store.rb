# Be sure to restart your server when you modify this file.

NinjaGold::Application.config.session_store :cookie_store, key: '_Ninja_Gold_session'
