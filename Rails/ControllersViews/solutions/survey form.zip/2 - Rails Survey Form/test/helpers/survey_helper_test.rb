require 'test_helper'

class SurveyHelperTest < ActionView::TestCase
end
