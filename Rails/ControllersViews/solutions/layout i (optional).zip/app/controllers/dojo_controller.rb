class DojoController < ApplicationController
  skip_before_filter :verify_autheticity_token

  def index
  end

  def seattle
  end

  def home
    render json: {name: params[:name], email: params[:email]}
  end
end
