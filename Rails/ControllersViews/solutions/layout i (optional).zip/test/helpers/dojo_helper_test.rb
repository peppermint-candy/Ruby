require 'test_helper'

class DojoHelperTest < ActionView::TestCase
end
