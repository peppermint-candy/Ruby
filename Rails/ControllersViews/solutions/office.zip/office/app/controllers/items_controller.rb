class ItemsController < ApplicationController
	def index
		@items = Item.all
	end

	def show
		@item = Item.find params[:id]
	end

	def new
	end

	def create
								# secured version of `params[:item]`
		Item.create params.require(:item).permit(:name)
		redirect_to "/items"
	end

	def edit
		@item = Item.find params[:id]
	end

	def update
		Item.update params[:id], params.require(:item).permit(:name)
		redirect_to "/items/" + params[:id]
	end

	def destroy
		Item.destroy params[:id]
		redirect_to "/items"
	end
end
