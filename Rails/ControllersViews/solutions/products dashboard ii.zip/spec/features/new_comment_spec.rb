require "rails_helper"

RSpec.describe "new comment" do
  it "displays correct fileds to create a new comment for a particular product" do
    category = Category.create(name: "Category1")
    product = category.products.create(name: "Product1", description: "Product1 description", pricing: 10.00)

    visit "/products/#{product.id}"

    expect(page).to have_field("Comment")
  end
end