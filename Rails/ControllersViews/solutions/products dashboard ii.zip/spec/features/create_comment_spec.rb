require "rails_helper"

RSpec.describe "creating a comment for a product" do
  it "creates a new comment and redirect to product show page" do
    category = Category.create(name: "Category1")
    product = category.products.create(name: "Product1", description: "Product1 description", pricing: 10.00)

    visit "/products/#{product.id}"
    fill_in "Comment", with: "Comment 1"
    click_button "Create"
    expect(current_path).to eq("/products/#{product.id}")
    expect(page).to have_text("Comment 1")
  end
end