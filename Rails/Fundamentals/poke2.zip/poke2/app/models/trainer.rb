class Trainer < ActiveRecord::Base
  belongs_to :organization
end
