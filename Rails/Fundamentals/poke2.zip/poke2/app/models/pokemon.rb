class Pokemon < ActiveRecord::Base
end
