class Organization < ActiveRecord::Base
end
